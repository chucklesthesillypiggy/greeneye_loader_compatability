"""Read-only check: python verify.py HANDOFF.dll GREENEYE.dll SERVER.exe"""
import hashlib,json,sys
from pathlib import Path
import pefile

def load(path):
 p=pefile.PE(str(path),fast_load=True);p.parse_data_directories(directories=[0,1]);return p
handoff_path,loader_path,server_path=map(Path,sys.argv[1:4])
handoff,loader,server=map(load,[handoff_path,loader_path,server_path])
assert all(p.FILE_HEADER.Machine==0x8664 for p in [handoff,loader,server]),'Expected x64 binaries'
assert handoff.FILE_HEADER.Characteristics&0x2000,'Handoff must be a DLL'
exports={e.name.decode():e for e in handoff.DIRECTORY_ENTRY_EXPORT.symbols if e.name}
loader_exports={e.name.decode():e for e in loader.DIRECTORY_ENTRY_EXPORT.symbols if e.name}
expected={'MiniDumpWriteDump':'dbgcore.MiniDumpWriteDump','MiniDumpReadDumpStream':'dbgcore.MiniDumpReadDumpStream'}
assert set(exports)==set(expected),'Unexpected handoff exports'
for name,target in expected.items():
 assert exports[name].forwarder.decode()==target
 assert name in loader_exports and loader_exports[name].forwarder,'Missing Greeneye/system forwarder'
assert {e.dll.lower() for e in handoff.DIRECTORY_ENTRY_IMPORT}=={b'kernel32.dll'},'Unexpected runtime dependency'
required=[]
for entry in server.DIRECTORY_ENTRY_IMPORT:
 if entry.dll.lower()==b'dbghelp.dll':
  for item in entry.imports:
   assert item.name is not None,'Unexpected ordinal import'
   name=item.name.decode();assert name in exports,'Missing server import '+name;required.append(name)
assert required,'No dbghelp imports found in supplied server'
entry=handoff.OPTIONAL_HEADER.AddressOfEntryPoint
assert any(s.Characteristics&0x20000000 and s.VirtualAddress<=entry<s.VirtualAddress+s.Misc_VirtualSize for s in handoff.sections),'Non-executable entry point'
report={'handoff_version':'1.0.0','architecture':'Windows x64','exports':expected,'covered_server_imports':required,'runtime_imports':['KERNEL32.dll'],'handoff_size':handoff_path.stat().st_size,'files':{label:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':path.stat().st_size} for label,path in [('handoff',handoff_path),('provided_greeneye_loader',loader_path),('provided_server',server_path)]},'scope':'Compilation and static PE/import/export checks passed; no Windows or DatHost runtime execution performed.'}
print(json.dumps(report,indent=2))
